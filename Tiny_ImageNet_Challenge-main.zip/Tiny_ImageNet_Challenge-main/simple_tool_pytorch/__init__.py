from .scheduler import *
from .autoaugment import *
from .mixup import *
from .labelsmoothing import *
from .randomerasing import *
